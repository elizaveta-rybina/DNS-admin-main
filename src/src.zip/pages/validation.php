<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link type="text/css" rel="stylesheet" href="/css/style_valid.css">
  <title>Validation</title>
</head>
<body>
  <div class="container">
    <h2>Вход</h2>
    <form action="main.html" onsubmit="return check_form()">
      <div class="mb-3">
        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Логин">
      </div>
      <div class="mb-3">
        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Пароль">
      </div>
      <div class="mb-3 form-check">
        <input type="checkbox" class="form-check-input" id="exampleCheck1">
        <label class="form-check-label" for="exampleCheck1">Запомнить</label>
      </div>
      <button type="submit" class="btn btn-primary">Войти</button>
      <div class="group">
        <a href="#">Забыли пароль?</a>
        <a href="#">Регистрация</a>
      </div>
    </form>
  </div>
  <script type="text/javascript" src="/javascript/js_valid.js"></script>
</body>
</html>