'use strict';

$(document).ready(function() {
    $('.deleteDomain', this).submit(function(event) {
		event.preventDefault();
        
        console.log($(this));
    });
});